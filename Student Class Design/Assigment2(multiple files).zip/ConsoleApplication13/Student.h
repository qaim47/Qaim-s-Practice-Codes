#ifndef STUDENT_H
#define STUDENT_H
#include<string>
using namespace std;

class Student {
private:
	string* name;
	int* id;
	string* courses;
	static int totalStudents;

public:
	Student();
	Student(string n, int i);
	Student(const Student& other);
	~Student();

	void setName(string n);
	void setId(int i);
	void setCourses(string c1, string c2, string c3);

	string getName() const;
	int getId() const;
	string* getCourses() const;

	void viewDetails() const;

	friend istream& operator>>(istream& in, Student& s);
	friend ostream& operator<<(ostream& out, const Student& s);

	bool operator==(const Student& other) const;

	static int getTotalStudents();
};

#endif
