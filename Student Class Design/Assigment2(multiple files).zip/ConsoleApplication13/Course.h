#ifndef COURSE_H
#define COURSE_H
#include<iostream>
#include<string>
using namespace std;
class Course {
private:
	string courseName;
	int credits;
	static int totalCourses;

public:
	Course();                                 
	Course(string name, int cr);              
	~Course();                                

	void setCourseName(string name);
	void setCredits(int cr);

	string getCourseName() const;
	int getCredits() const;

	void viewDetails() const;

	friend istream& operator>>(istream& in, Course& c);
	friend ostream& operator<<(ostream& out, const Course& c);

	int operator+(const Course& other) const;

	static int getTotalCourses();
};

#endif
