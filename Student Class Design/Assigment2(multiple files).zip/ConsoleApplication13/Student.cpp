#include"Student.h"
#include<iostream>
using namespace std;
int Student::totalStudents = 0;
Student::Student() {
	name = new string("");
	id = new int(0);
	courses = new string[3];
	totalStudents++;
}

Student::Student(string n, int i) {
	name = new string(n);
	id = new int(i);
	courses = new string[3];
	totalStudents++;
}

Student::Student(const Student& other) {
	name = new string(*other.name);
	id = new int(*other.id);
	courses = new string[3];
	for (int i = 0; i < 3; i++) {
		courses[i] = other.courses[i];
	}
}


Student::~Student() {
	delete name;
	delete id;
	delete[] courses;
	totalStudents--;
}


