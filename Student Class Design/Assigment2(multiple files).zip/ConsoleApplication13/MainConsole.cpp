﻿
#include"Student.h"
#include"Course.h"
using namespace std;

int main() {
	Student s1("Qaim", 101);
	s1.setCourses("Math", "Physics", "Chemistry");
	s1.viewDetails();

	Student s2 = s1; 
	s2.setName("Aiza");
	s2.viewDetails();

	
	Course c1("Math", 3);
	Course c2("Physics", 4);

	c1.viewDetails();
	c2.viewDetails();

	int totalCredits = c1 + c2;
	cout << "Total Credits: " << totalCredits << endl;

	if (s1 == s2) {
		cout << "Students have the same ID." <<endl;
	}
	else {
		cout << "Students have different IDs." << endl;
	}

	Student s3;
	cout << "Enter details for a new student:" << endl;
	cout << endl;
	cin >> s3;
	cout << endl;
	cout << "Details of the new student:" << endl << s3;
	cout << endl;
	Course c3;
	cout << "Enter details for a new course:" << endl;
	cin >> c3;
	cout << endl;
	cout << "Details of the new course:" << endl << c3;
	cout << endl;
	cout << "Total Students: " << Student::getTotalStudents() << endl;
	cout << "Total Courses: " << Course::getTotalCourses() << endl;

	return 0;
}
