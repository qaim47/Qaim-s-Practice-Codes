#include"Course.h"
int Course::totalCourses = 0;
Course::Course() : courseName(""), credits(0) {
	totalCourses++;
}


Course::Course(string name, int cr) : courseName(name), credits(cr) {
	totalCourses++;
}
Course::~Course() {
	totalCourses--;
}
void Course::setCourseName(string name) {
	courseName = name;
}
void Course::setCredits(int cr) {
	credits = cr;
}


string Course::getCourseName() const {
	return courseName;
}

int Course::getCredits() const {
	return credits;
}


void Course::viewDetails() const {
	cout << "Course Details:\n";
	cout << "Course Name: " << courseName << "\nCredits: " << credits << endl;
}


istream& operator>>(istream& in, Course& c) {
	cout << "Enter Course Name: ";
	in >> c.courseName;
	cout << "Enter Credits: ";
	in >> c.credits;
	return in;
}

ostream& operator<<(ostream& out, const Course& c) {
	out << "Course Name: " << c.courseName << "\nCredits: " << c.credits;
	return out;
}


int Course::operator+(const Course& other) const {
	return credits + other.credits;
}

int Course::getTotalCourses() {
	return totalCourses;
}
